package com.fiap.guilhermesouzadacruz_rm95088.model

data class Praia (
    val nome: String, val estado: String, val cidade: String
)
